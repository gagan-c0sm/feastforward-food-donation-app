
  # FeastForward food donation app

  This is a code bundle for FeastForward food donation app. The original project is available at https://www.figma.com/design/VCVP4MkPk3plyRmE3zNwgo/FeastForward-food-donation-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  